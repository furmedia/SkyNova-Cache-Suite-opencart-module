# Compatibilitate verificată

Data testelor: 3 octombrie 2026. Pachet: 0.6.0 development preview.

| Mediu | Verificare efectuată | Rezultat |
|---|---|---|
| PHP 5.6.40, 7.4.33, 8.2.32, 8.3.32 | Lint PHP și 263 aserțiuni ale nucleului pe fiecare runtime | Trecut |
| OpenCart 2.3.0.2 / PHP 5.6.40 | Clase/evenimente native, 52 aserțiuni; sesiune/coș simulate | Trecut |
| OpenCart 3.0.5.0 și 3.0.5.1 / PHP 8.3.32 | Clase/evenimente native, 52 aserțiuni pentru fiecare | Trecut |
| OpenCart 4.0.2.3 / PHP 8.3.32 | Clase/evenimente native, 49 aserțiuni | Trecut |
| OpenCart 4.1.0.3 / PHP 8.3.32 | Clase/evenimente native, 48 aserțiuni | Trecut |
| OpenCart 3.0.5.1, tema standard, MySQL 8.4.3 | Magazin izolat real: instalare ZIP, setări, MISS/HIT, vizitatori diferiți, produs/coș/checkout, purge, export, import invalid, dezinstalare/reinstalare | 51 verificări trecute |
| OpenCart 4.0.2.3, tema standard, DB reală | ZIP upload/install, salvare, MISS/HIT, sesiuni separate, coș bypass, dezinstalare | 34 verificări HTTP trecute |
| Cache comun OC3 | Două sesiuni, fragmente dinamice, cookies necunoscute, coș izolat, purge selectiv | 12 verificări trecute |
| Multistore OC3 | Salvare/export independent, origine runner, ID invalid | 4 verificări trecute |
| Date OC3 și OC4 | SQL selectiv, componente prin Loader nativ, izolare, indexuri reale, nonce și reaplicare | 23 verificări HTTP pe fiecare platformă |
| Browser premium | Panou responsive, controale noi, JS amânat/combinat/extras, CSS combinat și widgeturi cart izolate | 17 verificări trecute |
| Completări 0.4/0.5 OC3/OC4 | Resurse dinamice/antete, 404, două conturi reale, profil/logout, coș opt-in, widgeturi, loturi, seif, diagnostic pe sesiune, refuz ESI/CRON neautorizat | 73 verificări HTTP pe fiecare platformă |
| LiteSpeed / ESI | Protocol, semnătură, context, generație, refuz fără backend | Core verificat; niciun server Enterprise real conectat |
| Critical CSS | Extragere reală Chromium, două viewport-uri, fixture vizibil/nevizibil | Verificat; fără avertismente în fixture |
| Redis/Memcached, Cloudflare/S3 | Clienți/transport simulați, invalidare, fallback, payload, semnare și loturi | Serviciile/conturile reale nu au fost conectate |
| Panou admin desktop 1440px și mobil 390px | Browser real, capturi, fără overflow orizontal sau ID-uri duplicate | Verificat local |
| Journal 3.2.10 | Copiat numai în staging local; instalare admin și modificări native | Frontend blocat de Journal License Error; testarea completă nu este încheiată |

Fișiere probă: `validation/data-http.json`, `validation/data-oc4-http.json`, `validation/browser-premium.json`, `validation/php-matrix.json`, `validation/store-http.json`, `validation/benchmark-local.json`, `validation/admin-desktop.png`, `validation/admin-mobile.png`.

Benchmark istoric 0.1.0 (nu remăsurat pentru 0.3.0): 12 cereri măsurate per variantă după încălzire, aproximativ 222 ms mediană fără modul față de 89 ms cu HIT. Este durata răspunsului în mediul local PHP built-in/tema standard. Nu este un rezultat TrinityConcept, PageSpeed, Core Web Vitals sau o garanție comercială.

Testele nucleului pe PHP vechi nu înseamnă că orice versiune OpenCart/Journal rulează pe acel PHP. Respectați cerințele fiecărei platforme. OC1.5 și OC2.0–2.2 nu sunt suportate de instalatoarele actuale. OC2.3 și OC4.1 nu au încă test integral cu DB și browser. OC2.3 installerul vechi cere un mod SQL MYSQL40 care nu există în MySQL 8.4 local; nu am modificat installerul pentru a pretinde compatibilitate. OC4.0.2.3 are test HTTP cu DB reală. Fixture-ul Windows OC4 suprascrie session_path la / în configurația locală deoarece dirname pe Windows produce un cookie path incorect pentru rădăcina site-ului; sursa de referință și pachetul modulului nu sunt modificate de acest workaround.

Referința de magazin furnizată este TrinityConcept, OpenCart 3.0.5.1 și Journal 3.2.10, conform inventarului proiectului. Nu s-au făcut modificări sau teste de performanță pe producție. Accesul disponibil nu a fost folosit pentru a modifica magazinul live.

Acceptanța înainte de producție trebuie să includă Journal activat pe staging: pagină produs/categorie/căutare, filtre și AJAX, două sesiuni independente, clienți autentificați, monede/limbi/taxe, coș, cupoane, checkout, comenzi de test fără livrare/plată reală, PersistentCart și celelalte extensii instalate. Testați editarea prețului/stocului și invalidarea; comparați Lighthouse înainte/după în aceleași condiții.

Branding SkyNova Cache Suite. Capturile admin și testele au fost actualizate pentru 0.3.0; benchmark-ul rămâne explicit istoric. Identificatorii tehnici furmedia_cache și namespace-ul intern sunt păstrați pentru continuitatea instalării.

Dovezi suplimentare: `validation/shared-http.json`, `validation/multistore-http.json`, `validation/oc4-http.json`, `validation/browser-premium.json`, `validation/critical-css.json`.

Dovezi 0.4: `validation/completion-http.json`, `validation/completion-oc4-http.json`, `validation/php-matrix.json`. Testele din tabel pentru alte domenii includ baza verificată 0.3; fișierele probă păstrează versiunea și data proprie.

Politica statică de browser cache verificată pe un Apache 2.4.66 real, pornit separat pe loopback: 8 probe de antete, inclusiv excluderea HTML/PHP. Dovezi: validation/apache-policy.json. Nginx rămâne profil de integrare, fără probă pe server Nginx.

## Dovezi 0.6

- Nucleu: 300 aserțiuni pe fiecare PHP 5.6.40 / 7.4.33 / 8.2.32 / 8.3.32; 243 fișiere PHP lint/rulare, fără erori.
- Clase OpenCart native: 54 / 54 / 54 / 51 / 50 aserțiuni pe OC 2.3.0.2 / 3.0.5.0 / 3.0.5.1 / 4.0.2.3 / 4.1.0.3. Nu sunt teste de magazin integral pentru fiecare versiune.
- DB MySQL 8.4.3 locală: 25 probe cu tabele temporare proprii, EXPLAIN, ANALYZE/OPTIMIZE, programare zilnică, conversie MyISAM, backup înainte de ștergere, protecția coșurilor/sesiunilor și anonimizare. Tabelele fixture au fost eliminate la final.
- Admin/catalog HTTP: 15 probe noi pe fiecare OC3.0.5.1 / OC4.0.2.3; 73 probe de regresie completări pe fiecare. Configurațiile originale au fost restaurate.
- Chromium: 23 probe, inclusiv layout 1440/390 px, controalele noi, amânare per script, CSS/JS personalizat, video/audio și blocuri.
- Surse de dovezi: validation/advanced-db.json, validation/advanced-http.json, validation/advanced-oc4-http.json, validation/php-matrix.json, validation/browser-premium.json, validation/completion-http.json, validation/completion-oc4-http.json.

Importul extern este testat cu transport simulat și SHA256; rețeaua reală CDN nu a fost utilizată. APCu/Memcache: fallback verificat, servicii native indisponibile local. Programarea ANALYZE a fost verificată direct pe DB locală; CRON HTTPS de producție nu a fost executat. Nu există dovadă de accelerare pe catalogul real sau verificare frontend Journal activat.
